export * from "./deserialization.interface";
